export function calculatePoints(duration: number, quality: number, goalMinutes: number): number {
  let points = 0;
  
  // Base points for logging
  points += 10;
  
  // Duration points (max 50 points for meeting goal)
  const durationRatio = Math.min(duration / goalMinutes, 1);
  points += Math.floor(durationRatio * 50);
  
  // Quality bonus (10 points per quality level)
  points += quality * 10;
  
  return points;
}
