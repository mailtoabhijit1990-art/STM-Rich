import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const sleepLogs = pgTable("sleep_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  bedtime: timestamp("bedtime", { withTimezone: true }).notNull(),
  wakeTime: timestamp("wake_time", { withTimezone: true }).notNull(),
  quality: integer("quality").notNull(), // 1-5 scale
  notes: text("notes"),
  duration: integer("duration").notNull(), // in minutes
  points: integer("points").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().default(sql`now()`),
});

export const userStats = pgTable("user_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  totalPoints: integer("total_points").notNull().default(0),
  currentStreak: integer("current_streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  totalSleepLogs: integer("total_sleep_logs").notNull().default(0),
  averageSleepDuration: integer("average_sleep_duration").notNull().default(0), // in minutes
  sleepGoalMinutes: integer("sleep_goal_minutes").notNull().default(480), // 8 hours default
  level: integer("level").notNull().default(1),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().default(sql`now()`),
});

export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: varchar("key").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  unlocked: integer("unlocked").notNull().default(0), // 0 = locked, 1 = unlocked
  unlockedAt: timestamp("unlocked_at", { withTimezone: true }),
  progress: integer("progress").notNull().default(0),
  target: integer("target").notNull(),
});

// Insert schemas
export const insertSleepLogSchema = createInsertSchema(sleepLogs).omit({
  id: true,
  createdAt: true,
}).extend({
  bedtime: z.coerce.date(),
  wakeTime: z.coerce.date(),
});

export const insertUserStatsSchema = createInsertSchema(userStats).omit({
  id: true,
  updatedAt: true,
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
});

// Types
export type SleepLog = typeof sleepLogs.$inferSelect;
export type InsertSleepLog = z.infer<typeof insertSleepLogSchema>;

export type UserStats = typeof userStats.$inferSelect;
export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
