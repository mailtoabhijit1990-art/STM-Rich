import { 
  type SleepLog, 
  type InsertSleepLog,
  type UserStats,
  type InsertUserStats,
  type Achievement,
  type InsertAchievement
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Sleep Logs
  getSleepLogs(): Promise<SleepLog[]>;
  getSleepLog(id: string): Promise<SleepLog | undefined>;
  createSleepLog(log: InsertSleepLog): Promise<SleepLog>;
  deleteSleepLog(id: string): Promise<boolean>;
  
  // User Stats
  getUserStats(): Promise<UserStats>;
  updateUserStats(stats: Partial<UserStats>): Promise<UserStats>;
  
  // Achievements
  getAchievements(): Promise<Achievement[]>;
  getAchievement(id: string): Promise<Achievement | undefined>;
  updateAchievement(id: string, data: Partial<Achievement>): Promise<Achievement | undefined>;
  unlockAchievement(key: string): Promise<Achievement | undefined>;
}

const ACHIEVEMENTS_DATA = [
  {
    key: "first_night",
    name: "First Night",
    description: "Log your first sleep session",
    icon: "moon",
    unlocked: 0,
    progress: 0,
    target: 1,
  },
  {
    key: "early_bird",
    name: "Early Bird",
    description: "Wake up before 7 AM for 7 days",
    icon: "sunrise",
    unlocked: 0,
    progress: 0,
    target: 7,
  },
  {
    key: "week_warrior",
    name: "Week Warrior",
    description: "Log sleep for 7 consecutive days",
    icon: "flame",
    unlocked: 0,
    progress: 0,
    target: 7,
  },
  {
    key: "quality_sleeper",
    name: "Quality Sleeper",
    description: "Achieve excellent sleep quality 5 times",
    icon: "star",
    unlocked: 0,
    progress: 0,
    target: 5,
  },
  {
    key: "consistency_king",
    name: "Consistency King",
    description: "Maintain a 30-day streak",
    icon: "crown",
    unlocked: 0,
    progress: 0,
    target: 30,
  },
  {
    key: "perfect_week",
    name: "Perfect Week",
    description: "Meet your sleep goal every day for a week",
    icon: "target",
    unlocked: 0,
    progress: 0,
    target: 7,
  },
];

export class MemStorage implements IStorage {
  private sleepLogs: Map<string, SleepLog>;
  private userStats: UserStats;
  private achievements: Map<string, Achievement>;

  constructor() {
    this.sleepLogs = new Map();
    
    // Initialize user stats
    this.userStats = {
      id: randomUUID(),
      totalPoints: 0,
      currentStreak: 0,
      longestStreak: 0,
      totalSleepLogs: 0,
      averageSleepDuration: 0,
      sleepGoalMinutes: 480,
      level: 1,
      updatedAt: new Date(),
    };
    
    // Initialize achievements
    this.achievements = new Map();
    ACHIEVEMENTS_DATA.forEach((achievement) => {
      const id = randomUUID();
      this.achievements.set(id, {
        id,
        ...achievement,
        unlockedAt: null,
      });
    });
  }

  // Sleep Logs
  async getSleepLogs(): Promise<SleepLog[]> {
    return Array.from(this.sleepLogs.values()).sort(
      (a, b) => new Date(b.bedtime).getTime() - new Date(a.bedtime).getTime()
    );
  }

  async getSleepLog(id: string): Promise<SleepLog | undefined> {
    return this.sleepLogs.get(id);
  }

  async createSleepLog(insertLog: InsertSleepLog): Promise<SleepLog> {
    const id = randomUUID();
    const log: SleepLog = {
      id,
      ...insertLog,
      createdAt: new Date(),
    };
    
    this.sleepLogs.set(id, log);
    
    // Update user stats
    await this.updateStatsAfterLog(log);
    
    return log;
  }

  async deleteSleepLog(id: string): Promise<boolean> {
    const deleted = this.sleepLogs.delete(id);
    if (deleted) {
      await this.recalculateStats();
    }
    return deleted;
  }

  // User Stats
  async getUserStats(): Promise<UserStats> {
    return this.userStats;
  }

  async updateUserStats(stats: Partial<UserStats>): Promise<UserStats> {
    this.userStats = {
      ...this.userStats,
      ...stats,
      updatedAt: new Date(),
    };
    return this.userStats;
  }

  // Achievements
  async getAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }

  async getAchievement(id: string): Promise<Achievement | undefined> {
    return this.achievements.get(id);
  }

  async updateAchievement(id: string, data: Partial<Achievement>): Promise<Achievement | undefined> {
    const achievement = this.achievements.get(id);
    if (!achievement) return undefined;
    
    const updated = { ...achievement, ...data };
    this.achievements.set(id, updated);
    return updated;
  }

  async unlockAchievement(key: string): Promise<Achievement | undefined> {
    const achievement = Array.from(this.achievements.values()).find(a => a.key === key);
    if (!achievement || achievement.unlocked) return undefined;
    
    achievement.unlocked = 1;
    achievement.unlockedAt = new Date();
    this.achievements.set(achievement.id, achievement);
    
    return achievement;
  }

  // Helper methods
  private async updateStatsAfterLog(log: SleepLog): Promise<void> {
    const logs = await this.getSleepLogs();
    
    // Update total logs count
    this.userStats.totalSleepLogs = logs.length;
    
    // Update average sleep duration
    const totalDuration = logs.reduce((sum, l) => sum + l.duration, 0);
    this.userStats.averageSleepDuration = Math.round(totalDuration / logs.length);
    
    // Update points
    this.userStats.totalPoints += log.points;
    
    // Update level (100 points per level)
    this.userStats.level = Math.floor(this.userStats.totalPoints / 100) + 1;
    
    // Update streak
    await this.calculateStreak();
    
    // Check and update achievements
    await this.checkAchievements(log);
    
    this.userStats.updatedAt = new Date();
  }

  private async calculateStreak(): Promise<void> {
    const logs = await this.getSleepLogs();
    if (logs.length === 0) {
      this.userStats.currentStreak = 0;
      return;
    }
    
    // Sort logs by bedtime
    const sortedLogs = [...logs].sort(
      (a, b) => new Date(a.bedtime).getTime() - new Date(b.bedtime).getTime()
    );
    
    // Get unique dates
    const dates = sortedLogs.map(log => {
      const date = new Date(log.bedtime);
      return new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
    });
    
    const uniqueDates = Array.from(new Set(dates)).sort((a, b) => a - b);
    
    if (uniqueDates.length === 0) {
      this.userStats.currentStreak = 0;
      return;
    }
    
    // Calculate current streak from today backwards
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayTime = today.getTime();
    
    let currentStreak = 0;
    let checkDate = todayTime;
    
    for (let i = uniqueDates.length - 1; i >= 0; i--) {
      if (uniqueDates[i] === checkDate) {
        currentStreak++;
        checkDate -= 24 * 60 * 60 * 1000; // Go back one day
      } else if (uniqueDates[i] < checkDate) {
        // Gap in streak
        break;
      }
    }
    
    this.userStats.currentStreak = currentStreak;
    
    // Update longest streak if current is higher
    if (currentStreak > this.userStats.longestStreak) {
      this.userStats.longestStreak = currentStreak;
    }
  }

  private async checkAchievements(log: SleepLog): Promise<void> {
    const logs = await this.getSleepLogs();
    const achievements = await this.getAchievements();
    
    // First Night
    const firstNight = achievements.find(a => a.key === "first_night");
    if (firstNight && !firstNight.unlocked && logs.length >= 1) {
      await this.unlockAchievement("first_night");
    }
    
    // Quality Sleeper (5 excellent quality sleeps)
    const qualitySleeper = achievements.find(a => a.key === "quality_sleeper");
    if (qualitySleeper && !qualitySleeper.unlocked) {
      const excellentCount = logs.filter(l => l.quality === 5).length;
      if (qualitySleeper.id) {
        await this.updateAchievement(qualitySleeper.id, { progress: excellentCount });
      }
      if (excellentCount >= 5) {
        await this.unlockAchievement("quality_sleeper");
      }
    }
    
    // Week Warrior (7 day streak)
    const weekWarrior = achievements.find(a => a.key === "week_warrior");
    if (weekWarrior && !weekWarrior.unlocked) {
      if (weekWarrior.id) {
        await this.updateAchievement(weekWarrior.id, { progress: this.userStats.currentStreak });
      }
      if (this.userStats.currentStreak >= 7) {
        await this.unlockAchievement("week_warrior");
      }
    }
    
    // Consistency King (30 day streak)
    const consistencyKing = achievements.find(a => a.key === "consistency_king");
    if (consistencyKing && !consistencyKing.unlocked) {
      if (consistencyKing.id) {
        await this.updateAchievement(consistencyKing.id, { progress: this.userStats.currentStreak });
      }
      if (this.userStats.currentStreak >= 30) {
        await this.unlockAchievement("consistency_king");
      }
    }
    
    // Early Bird (wake up before 7 AM for 7 days)
    const earlyBird = achievements.find(a => a.key === "early_bird");
    if (earlyBird && !earlyBird.unlocked) {
      const earlyWakes = logs.filter(l => {
        const wakeHour = new Date(l.wakeTime).getHours();
        return wakeHour < 7;
      }).length;
      if (earlyBird.id) {
        await this.updateAchievement(earlyBird.id, { progress: earlyWakes });
      }
      if (earlyWakes >= 7) {
        await this.unlockAchievement("early_bird");
      }
    }
    
    // Perfect Week (meet goal every day for a week)
    const perfectWeek = achievements.find(a => a.key === "perfect_week");
    if (perfectWeek && !perfectWeek.unlocked) {
      const goalMeets = logs.filter(l => l.duration >= this.userStats.sleepGoalMinutes).length;
      if (perfectWeek.id) {
        await this.updateAchievement(perfectWeek.id, { progress: Math.min(goalMeets, 7) });
      }
      if (goalMeets >= 7) {
        await this.unlockAchievement("perfect_week");
      }
    }
  }

  private async recalculateStats(): Promise<void> {
    const logs = await this.getSleepLogs();
    
    if (logs.length === 0) {
      this.userStats.totalSleepLogs = 0;
      this.userStats.averageSleepDuration = 0;
      this.userStats.totalPoints = 0;
      this.userStats.level = 1;
      this.userStats.currentStreak = 0;
      this.userStats.longestStreak = 0;
      return;
    }
    
    // Recalculate everything
    this.userStats.totalSleepLogs = logs.length;
    
    const totalDuration = logs.reduce((sum, l) => sum + l.duration, 0);
    this.userStats.averageSleepDuration = Math.round(totalDuration / logs.length);
    
    this.userStats.totalPoints = logs.reduce((sum, l) => sum + l.points, 0);
    this.userStats.level = Math.floor(this.userStats.totalPoints / 100) + 1;
    
    await this.calculateStreak();
    
    this.userStats.updatedAt = new Date();
  }
}

export const storage = new MemStorage();
