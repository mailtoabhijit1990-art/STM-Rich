import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSleepLogSchema } from "@shared/schema";
import { calculatePoints } from "@shared/utils";

export async function registerRoutes(app: Express): Promise<Server> {
  // Sleep Logs endpoints
  app.get("/api/sleep-logs", async (_req, res) => {
    try {
      const logs = await storage.getSleepLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sleep logs" });
    }
  });

  app.get("/api/sleep-logs/:id", async (req, res) => {
    try {
      const log = await storage.getSleepLog(req.params.id);
      if (!log) {
        return res.status(404).json({ error: "Sleep log not found" });
      }
      res.json(log);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sleep log" });
    }
  });

  app.post("/api/sleep-logs", async (req, res) => {
    try {
      // Parse and validate input
      const validatedData = insertSleepLogSchema.parse(req.body);
      
      // Calculate duration in minutes
      const bedtime = new Date(validatedData.bedtime);
      const wakeTime = new Date(validatedData.wakeTime);
      const duration = Math.round((wakeTime.getTime() - bedtime.getTime()) / (1000 * 60));
      
      // Get user stats for goal
      const stats = await storage.getUserStats();
      
      // Calculate points
      const points = calculatePoints(duration, validatedData.quality, stats.sleepGoalMinutes);
      
      // Create sleep log with calculated values
      const log = await storage.createSleepLog({
        ...validatedData,
        duration,
        points,
      });
      
      res.status(201).json(log);
    } catch (error) {
      console.error("Error creating sleep log:", error);
      if (error instanceof Error && error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid input data" });
      }
      res.status(500).json({ error: "Failed to create sleep log" });
    }
  });

  app.delete("/api/sleep-logs/:id", async (req, res) => {
    try {
      const success = await storage.deleteSleepLog(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Sleep log not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete sleep log" });
    }
  });

  // User Stats endpoints
  app.get("/api/stats", async (_req, res) => {
    try {
      const stats = await storage.getUserStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  app.put("/api/stats", async (req, res) => {
    try {
      const stats = await storage.updateUserStats(req.body);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to update stats" });
    }
  });

  // Achievements endpoints
  app.get("/api/achievements", async (_req, res) => {
    try {
      const achievements = await storage.getAchievements();
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch achievements" });
    }
  });

  app.get("/api/achievements/:id", async (req, res) => {
    try {
      const achievement = await storage.getAchievement(req.params.id);
      if (!achievement) {
        return res.status(404).json({ error: "Achievement not found" });
      }
      res.json(achievement);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch achievement" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
