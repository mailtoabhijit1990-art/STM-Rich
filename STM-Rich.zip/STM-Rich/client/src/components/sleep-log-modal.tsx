import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { SleepLogForm } from "@/components/sleep-log-form";

interface SleepLogModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: {
    bedtime: Date;
    wakeTime: Date;
    quality: number;
    notes: string;
    duration: number;
  }) => void;
  isSubmitting?: boolean;
}

export function SleepLogModal({ open, onClose, onSubmit, isSubmitting = false }: SleepLogModalProps) {
  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-md" data-testid="modal-sleep-log">
        <DialogHeader>
          <DialogTitle className="text-2xl font-semibold">Log Your Sleep</DialogTitle>
        </DialogHeader>
        <SleepLogForm
          onSubmit={onSubmit}
          onCancel={onClose}
          isSubmitting={isSubmitting}
        />
      </DialogContent>
    </Dialog>
  );
}
