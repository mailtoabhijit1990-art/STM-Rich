import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { getQualityLabel } from "@/lib/utils";
import { insertSleepLogSchema } from "@shared/schema";

const sleepLogFormSchema = insertSleepLogSchema.extend({
  bedtime: z.date(),
  wakeTime: z.date(),
});

type SleepLogFormValues = z.infer<typeof sleepLogFormSchema>;

interface SleepLogFormProps {
  onSubmit: (data: SleepLogFormValues) => void;
  onCancel: () => void;
  isSubmitting?: boolean;
}

export function SleepLogForm({ onSubmit, onCancel, isSubmitting = false }: SleepLogFormProps) {
  // Set default bedtime to yesterday 11 PM and wake time to today 7 AM
  const getDefaultBedtime = () => {
    const date = new Date();
    date.setDate(date.getDate() - 1);
    date.setHours(23, 0, 0, 0);
    return date;
  };

  const getDefaultWakeTime = () => {
    const date = new Date();
    date.setHours(7, 0, 0, 0);
    return date;
  };

  const form = useForm<SleepLogFormValues>({
    resolver: zodResolver(sleepLogFormSchema),
    defaultValues: {
      bedtime: getDefaultBedtime(),
      wakeTime: getDefaultWakeTime(),
      quality: 3,
      notes: "",
      duration: 0,
      points: 0,
    },
  });

  const handleSubmit = (values: SleepLogFormValues) => {
    // Calculate duration
    const duration = Math.round((values.wakeTime.getTime() - values.bedtime.getTime()) / (1000 * 60));
    
    onSubmit({
      ...values,
      duration,
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6 mt-4">
        <div className="space-y-4">
          <FormField
            control={form.control}
            name="bedtime"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm font-medium flex items-center gap-2">
                  <Moon className="w-4 h-4 text-primary" />
                  Bedtime
                </FormLabel>
                <FormControl>
                  <input
                    type="datetime-local"
                    value={field.value instanceof Date && !isNaN(field.value.getTime())
                      ? field.value.toISOString().slice(0, 16) 
                      : ""}
                    onChange={(e) => field.onChange(new Date(e.target.value))}
                    className="w-full px-4 py-2.5 rounded-md border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    data-testid="input-bedtime"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="wakeTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm font-medium flex items-center gap-2">
                  <Sun className="w-4 h-4 text-primary" />
                  Wake Time
                </FormLabel>
                <FormControl>
                  <input
                    type="datetime-local"
                    value={field.value instanceof Date && !isNaN(field.value.getTime())
                      ? field.value.toISOString().slice(0, 16) 
                      : ""}
                    onChange={(e) => field.onChange(new Date(e.target.value))}
                    className="w-full px-4 py-2.5 rounded-md border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    data-testid="input-waketime"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="quality"
            render={({ field }) => (
              <FormItem>
                <div className="flex items-center justify-between mb-3">
                  <FormLabel className="text-sm font-medium">Sleep Quality</FormLabel>
                  <span className="text-sm font-semibold text-primary" data-testid="text-quality-label">
                    {getQualityLabel(field.value)}
                  </span>
                </div>
                <FormControl>
                  <Slider
                    value={[field.value]}
                    onValueChange={(value) => field.onChange(value[0])}
                    min={1}
                    max={5}
                    step={1}
                    className="py-2"
                    data-testid="slider-quality"
                  />
                </FormControl>
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>Poor</span>
                  <span>Excellent</span>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm font-medium">
                  Notes (Optional)
                </FormLabel>
                <FormControl>
                  <Textarea
                    {...field}
                    value={field.value || ""}
                    placeholder="How did you sleep? Any dreams or observations..."
                    className="resize-none min-h-[100px]"
                    data-testid="input-notes"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            className="flex-1"
            disabled={isSubmitting}
            data-testid="button-cancel"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            className="flex-1"
            disabled={isSubmitting}
            data-testid="button-submit-log"
          >
            {isSubmitting ? "Saving..." : "Save Sleep Log"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
