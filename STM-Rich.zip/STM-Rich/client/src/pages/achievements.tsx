import { useQuery } from "@tanstack/react-query";
import { Trophy, Lock, Loader2, Moon, Sunrise, Flame, Star, Crown, Target } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import type { Achievement } from "@shared/schema";

const iconMap: Record<string, React.ReactNode> = {
  moon: <Moon className="w-8 h-8" />,
  sunrise: <Sunrise className="w-8 h-8" />,
  flame: <Flame className="w-8 h-8" />,
  star: <Star className="w-8 h-8" />,
  crown: <Crown className="w-8 h-8" />,
  target: <Target className="w-8 h-8" />,
};

export default function Achievements() {
  const { data: achievements, isLoading } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center pb-24">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const unlockedCount = achievements?.filter(a => a.unlocked === 1).length || 0;
  const totalCount = achievements?.length || 0;

  return (
    <div className="min-h-screen pb-24">
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">Achievements</h1>
          <div className="flex items-center gap-3">
            <Progress 
              value={(unlockedCount / totalCount) * 100} 
              className="flex-1 h-2"
            />
            <span className="text-sm font-medium" data-testid="text-achievement-count">
              {unlockedCount}/{totalCount}
            </span>
          </div>
        </div>

        <div className="grid gap-4">
          {achievements?.map((achievement) => (
            <Card 
              key={achievement.id}
              className={`${achievement.unlocked === 1 ? "border-primary/30" : "opacity-75"}`}
              data-testid={`achievement-${achievement.id}`}
            >
              <CardContent className="p-5">
                <div className="flex gap-4">
                  <div className={`
                    w-16 h-16 rounded-full flex items-center justify-center flex-shrink-0
                    ${achievement.unlocked === 1
                      ? "bg-primary/20 text-primary" 
                      : "bg-muted"}
                  `}>
                    {achievement.unlocked === 1 ? (iconMap[achievement.icon] || <Lock className="w-8 h-8" />) : <Lock className="w-6 h-6 text-muted-foreground" />}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1 flex-wrap">
                      <h3 className="font-semibold">{achievement.name}</h3>
                      {achievement.unlocked === 1 && (
                        <Badge variant="default" className="text-xs">
                          <Trophy className="w-3 h-3 mr-1" />
                          Unlocked
                        </Badge>
                      )}
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-3">
                      {achievement.description}
                    </p>
                    
                    {achievement.unlocked === 0 && (
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Progress</span>
                          <span className="font-medium">
                            {achievement.progress}/{achievement.target}
                          </span>
                        </div>
                        <Progress 
                          value={(achievement.progress / achievement.target) * 100} 
                          className="h-1.5"
                        />
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {unlockedCount === 0 && (
          <Card className="bg-muted/30">
            <CardContent className="p-6 text-center">
              <Trophy className="w-12 h-12 mx-auto mb-3 text-muted-foreground" />
              <h3 className="font-semibold mb-2">No Achievements Yet</h3>
              <p className="text-sm text-muted-foreground">
                Start logging your sleep to unlock achievements and earn rewards!
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
