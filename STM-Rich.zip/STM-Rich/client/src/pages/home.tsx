import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Moon, TrendingUp, Flame, Award, Plus, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { SleepLogModal } from "@/components/sleep-log-modal";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { getGreeting, formatDuration, getQualityLabel } from "@/lib/utils";
import type { UserStats, SleepLog } from "@shared/schema";
import emptyStateImage from "@assets/generated_images/Peaceful_sleep_illustration_empty_state_da3c5062.png";

export default function Home() {
  const [showLogModal, setShowLogModal] = useState(false);
  const { toast } = useToast();
  
  const greeting = getGreeting();
  
  const { data: stats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ["/api/stats"],
  });
  
  const { data: sleepLogs, isLoading: logsLoading } = useQuery<SleepLog[]>({
    queryKey: ["/api/sleep-logs"],
  });
  
  const createLogMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/sleep-logs", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sleep-logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/achievements"] });
      toast({
        title: "Sleep Logged!",
        description: `You earned ${stats ? Math.min(100, 60) : 60} points!`,
      });
      setShowLogModal(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to log sleep. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const isLoading = statsLoading || logsLoading;
  const recentLog = sleepLogs?.[0];
  const nextLevelPoints = (stats?.level || 1) * 100;
  
  const dailyQuest = {
    title: stats && stats.totalSleepLogs > 0 ? "Keep the Streak!" : "Log Your First Sleep",
    description: stats && stats.totalSleepLogs > 0 
      ? "Continue your amazing sleep tracking journey" 
      : "Track your sleep tonight to start your journey",
    progress: stats?.totalSleepLogs || 0,
    target: 1,
  };

  const handleLogSleep = (data: any) => {
    createLogMutation.mutate(data);
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24">
      <div className="p-6 space-y-6">
        {/* Greeting Card */}
        <Card className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
          <CardContent className="p-6">
            <h1 className="text-3xl font-bold mb-1" data-testid="text-greeting">
              {greeting}!
            </h1>
            <p className="text-muted-foreground">Ready to track your sleep journey?</p>
            
            <div className="flex items-center gap-4 mt-4 flex-wrap">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Level</p>
                  <p className="font-semibold" data-testid="text-level">{stats?.level || 1}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                  <Flame className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Streak</p>
                  <p className="font-semibold" data-testid="text-streak">{stats?.currentStreak || 0} days</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                  <Award className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Points</p>
                  <p className="font-semibold" data-testid="text-points">{stats?.totalPoints || 0}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Log Button */}
        <Button
          onClick={() => setShowLogModal(true)}
          size="lg"
          className="w-full h-16 text-lg font-semibold"
          data-testid="button-quick-log"
        >
          <Plus className="w-5 h-5 mr-2" />
          Log Sleep
        </Button>

        {/* Today's Summary */}
        {recentLog ? (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Last Sleep</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Duration</span>
                <span className="font-semibold">{formatDuration(recentLog.duration)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Quality</span>
                <Badge variant="secondary">{getQualityLabel(recentLog.quality)}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Points Earned</span>
                <span className="font-semibold text-primary">+{recentLog.points}</span>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <img 
                src={emptyStateImage} 
                alt="Start tracking sleep"
                className="w-48 h-36 mx-auto mb-4 object-contain"
              />
              <h3 className="font-semibold text-lg mb-2">No Sleep Logged Yet</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Start your journey by logging your first sleep session
              </p>
            </CardContent>
          </Card>
        )}

        {/* Daily Quest */}
        <Card>
          <CardHeader className="pb-3 gap-2 flex-row items-center justify-between flex-wrap">
            <CardTitle className="text-lg">Daily Quest</CardTitle>
            <Badge variant="outline" className="text-xs">
              {dailyQuest.progress}/{dailyQuest.target}
            </Badge>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <h4 className="font-medium mb-1">{dailyQuest.title}</h4>
              <p className="text-sm text-muted-foreground">{dailyQuest.description}</p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-medium">{Math.min(Math.round((dailyQuest.progress / dailyQuest.target) * 100), 100)}%</span>
              </div>
              <Progress 
                value={Math.min((dailyQuest.progress / dailyQuest.target) * 100, 100)} 
                className="h-2"
              />
            </div>
          </CardContent>
        </Card>

        {/* Level Progress */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Level Progress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Level {stats?.level || 1}</span>
              <span className="font-medium">
                {stats?.totalPoints || 0} / {nextLevelPoints} XP
              </span>
            </div>
            <Progress 
              value={((stats?.totalPoints || 0) / nextLevelPoints) * 100} 
              className="h-2"
            />
            <p className="text-xs text-muted-foreground text-center">
              {nextLevelPoints - (stats?.totalPoints || 0)} XP until Level {(stats?.level || 1) + 1}
            </p>
          </CardContent>
        </Card>
      </div>

      <SleepLogModal 
        open={showLogModal}
        onClose={() => setShowLogModal(false)}
        onSubmit={handleLogSleep}
        isSubmitting={createLogMutation.isPending}
      />
    </div>
  );
}
