import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getMonthDays, isSameDay, formatDate, getQualityLabel, formatDuration, getQualityColor } from "@/lib/utils";
import type { SleepLog } from "@shared/schema";

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  
  const { data: sleepLogs, isLoading } = useQuery<SleepLog[]>({
    queryKey: ["/api/sleep-logs"],
  });
  
  const monthDays = getMonthDays(currentDate.getFullYear(), currentDate.getMonth());
  const monthName = currentDate.toLocaleDateString("en-US", { month: "long", year: "numeric" });
  
  // Map sleep logs by date
  const sleepDataMap = new Map<string, { quality: number; duration: number }>();
  sleepLogs?.forEach(log => {
    const date = new Date(log.bedtime);
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    sleepDataMap.set(key, { quality: log.quality, duration: log.duration });
  });
  
  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
    setSelectedDate(null);
  };
  
  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
    setSelectedDate(null);
  };
  
  const getSleepForDate = (date: Date) => {
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    return sleepDataMap.get(key);
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center pb-24">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }
  
  const isCurrentMonth = (date: Date) => {
    return date.getMonth() === currentDate.getMonth();
  };
  
  const selectedDateSleep = selectedDate ? getSleepForDate(selectedDate) : null;

  return (
    <div className="min-h-screen pb-24">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between gap-4">
          <h1 className="text-2xl font-bold" data-testid="text-month-year">{monthName}</h1>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={handlePrevMonth}
              data-testid="button-prev-month"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={handleNextMonth}
              data-testid="button-next-month"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Calendar Grid */}
        <Card>
          <CardContent className="p-4">
            {/* Weekday headers */}
            <div className="grid grid-cols-7 gap-2 mb-2">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div key={day} className="text-center text-xs font-medium text-muted-foreground py-2">
                  {day}
                </div>
              ))}
            </div>
            
            {/* Calendar days */}
            <div className="grid grid-cols-7 gap-2">
              {monthDays.map((date, index) => {
                const sleepData = getSleepForDate(date);
                const isToday = isSameDay(date, new Date());
                const isSelected = selectedDate && isSameDay(date, selectedDate);
                const inCurrentMonth = isCurrentMonth(date);
                
                return (
                  <button
                    key={index}
                    onClick={() => setSelectedDate(date)}
                    className={`
                      aspect-square p-1 rounded-md text-sm font-medium relative
                      hover-elevate active-elevate-2
                      ${!inCurrentMonth ? "text-muted-foreground/40" : ""}
                      ${isToday ? "ring-2 ring-primary" : ""}
                      ${isSelected ? "bg-accent" : ""}
                    `}
                    data-testid={`calendar-day-${date.getDate()}`}
                  >
                    <div className="absolute inset-0 flex items-center justify-center">
                      {date.getDate()}
                    </div>
                    {sleepData && (
                      <div className={`absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-${getQualityColor(sleepData.quality)}`} />
                    )}
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Selected Date Details */}
        {selectedDate && (
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-4" data-testid="text-selected-date">
                {formatDate(selectedDate)}
              </h3>
              
              {selectedDateSleep ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Duration</span>
                    <span className="font-semibold">{formatDuration(selectedDateSleep.duration)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Quality</span>
                    <Badge variant="secondary">{getQualityLabel(selectedDateSleep.quality)}</Badge>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No sleep logged for this date
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Legend */}
        <Card>
          <CardContent className="p-4">
            <h4 className="text-sm font-medium mb-3">Quality Legend</h4>
            <div className="flex flex-wrap gap-3">
              {[
                { label: "Poor", color: "quality-poor" },
                { label: "Fair", color: "quality-fair" },
                { label: "Good", color: "quality-good" },
                { label: "Great", color: "quality-great" },
                { label: "Excellent", color: "quality-excellent" },
              ].map(({ label, color }) => (
                <div key={label} className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full bg-${color}`} />
                  <span className="text-xs text-muted-foreground">{label}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
