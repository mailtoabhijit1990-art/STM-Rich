import { useQuery } from "@tanstack/react-query";
import { TrendingUp, Moon, Clock, Target, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { formatDuration } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";
import type { UserStats, SleepLog } from "@shared/schema";

export default function Stats() {
  const { data: stats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ["/api/stats"],
  });
  
  const { data: sleepLogs, isLoading: logsLoading } = useQuery<SleepLog[]>({
    queryKey: ["/api/sleep-logs"],
  });
  
  const isLoading = statsLoading || logsLoading;
  
  // Calculate weekly data from sleep logs
  const last7Days = new Array(7).fill(0).map((_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    return date;
  });
  
  const weeklyData = last7Days.map(date => {
    const dayName = date.toLocaleDateString("en-US", { weekday: "short" });
    const dayLogs = sleepLogs?.filter(log => {
      const logDate = new Date(log.bedtime);
      return (
        logDate.getDate() === date.getDate() &&
        logDate.getMonth() === date.getMonth() &&
        logDate.getFullYear() === date.getFullYear()
      );
    }) || [];
    
    const totalMinutes = dayLogs.reduce((sum, log) => sum + log.duration, 0);
    return {
      day: dayName,
      hours: Math.round((totalMinutes / 60) * 10) / 10,
    };
  });
  
  const qualityTrend = (sleepLogs || []).slice(0, 7).reverse().map((log, i) => ({
    day: `Day ${i + 1}`,
    quality: log.quality,
  }));

  const averagePercentage = (stats?.sleepGoalMinutes || 0) > 0
    ? ((stats?.averageSleepDuration || 0) / (stats?.sleepGoalMinutes || 1)) * 100
    : 0;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center pb-24">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24">
      <div className="p-6 space-y-6">
        <h1 className="text-2xl font-bold">Sleep Statistics</h1>

        {/* Overview Cards */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <Moon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Total Logs</p>
                  <p className="text-xl font-bold" data-testid="text-total-logs">
                    {stats?.totalSleepLogs || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Avg Sleep</p>
                  <p className="text-xl font-bold" data-testid="text-avg-sleep">
                    {(stats?.averageSleepDuration || 0) > 0 
                      ? formatDuration(stats?.averageSleepDuration || 0)
                      : "0h"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Best Streak</p>
                  <p className="text-xl font-bold" data-testid="text-best-streak">
                    {stats?.longestStreak || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <Target className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Goal Met</p>
                  <p className="text-xl font-bold">
                    {Math.round(averagePercentage)}%
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sleep Goal Progress */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Sleep Goal</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Daily Target</span>
              <span className="font-medium">{formatDuration(stats?.sleepGoalMinutes || 480)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Average Sleep</span>
              <span className="font-medium">
                {(stats?.averageSleepDuration || 0) > 0 
                  ? formatDuration(stats?.averageSleepDuration || 0)
                  : "0h"}
              </span>
            </div>
            <Progress value={averagePercentage} className="h-2" />
          </CardContent>
        </Card>

        {/* Weekly Sleep Duration Chart */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Weekly Sleep Duration</CardTitle>
          </CardHeader>
          <CardContent>
            {(stats?.totalSleepLogs || 0) > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                  <XAxis dataKey="day" fontSize={12} />
                  <YAxis fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                    }}
                  />
                  <Bar dataKey="hours" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[200px] flex items-center justify-center text-sm text-muted-foreground">
                No sleep data to display yet
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quality Trend Chart */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Sleep Quality Trend</CardTitle>
          </CardHeader>
          <CardContent>
            {(stats?.totalSleepLogs || 0) > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={qualityTrend}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                  <XAxis dataKey="day" fontSize={12} />
                  <YAxis domain={[0, 5]} fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="quality" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={{ fill: 'hsl(var(--primary))', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[200px] flex items-center justify-center text-sm text-muted-foreground">
                No quality data to display yet
              </div>
            )}
          </CardContent>
        </Card>

        {/* Insights */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Insights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {(stats?.totalSleepLogs || 0) === 0 ? (
              <p className="text-sm text-muted-foreground">
                Start logging your sleep to see personalized insights
              </p>
            ) : (
              <>
                <p className="text-sm">
                  Your average sleep duration is <span className="font-semibold text-primary">{formatDuration(stats?.averageSleepDuration || 0)}</span>
                </p>
                <p className="text-sm text-muted-foreground">
                  Keep tracking to unlock more insights about your sleep patterns!
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
