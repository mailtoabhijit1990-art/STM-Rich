import { useQuery } from "@tanstack/react-query";
import { User, Target, Settings, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { ThemeToggle } from "@/components/theme-toggle";
import { formatDuration } from "@/lib/utils";
import type { UserStats } from "@shared/schema";

export default function Profile() {
  const { data: stats, isLoading } = useQuery<UserStats>({
    queryKey: ["/api/stats"],
  });
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center pb-24">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const handleGoalChange = () => {
    // Will implement in integration phase
    console.log("Goal change requested");
  };

  return (
    <div className="min-h-screen pb-24">
      <div className="p-6 space-y-6">
        <h1 className="text-2xl font-bold">Profile</h1>

        {/* User Info Card */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
                <User className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h2 className="text-xl font-semibold">Sleep Tracker</h2>
                <p className="text-sm text-muted-foreground">Level {stats?.level || 1}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 pt-4 border-t">
              <div>
                <p className="text-sm text-muted-foreground">Total Points</p>
                <p className="text-2xl font-bold" data-testid="text-total-points">
                  {stats?.totalPoints || 0}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Sleep Logs</p>
                <p className="text-2xl font-bold" data-testid="text-total-sleep-logs">
                  {stats?.totalSleepLogs || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sleep Goal Card */}
        <Card>
          <CardHeader className="pb-3 gap-2 flex-row items-center justify-between flex-wrap">
            <CardTitle className="text-lg flex items-center gap-2">
              <Target className="w-5 h-5 text-primary" />
              Sleep Goal
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-sm">Daily Target</Label>
              <span className="text-lg font-semibold" data-testid="text-sleep-goal">
                {formatDuration(stats?.sleepGoalMinutes || 480)}
              </span>
            </div>
            <Button 
              variant="outline" 
              className="w-full"
              onClick={handleGoalChange}
              data-testid="button-change-goal"
            >
              Change Goal
            </Button>
            <p className="text-xs text-muted-foreground">
              Recommended: 7-9 hours of sleep per night
            </p>
          </CardContent>
        </Card>

        {/* Settings Card */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Settings className="w-5 h-5 text-primary" />
              Appearance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium">Theme</Label>
                <p className="text-xs text-muted-foreground">Toggle between light and dark mode</p>
              </div>
              <ThemeToggle />
            </div>
          </CardContent>
        </Card>

        {/* About Card */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">About DreamQuest</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm text-muted-foreground">
              Track your sleep, build healthy habits, and unlock achievements. 
              Monitor your sleep patterns and earn points for consistency.
            </p>
            <p className="text-xs text-muted-foreground">
              Version 1.0.0
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
